var express = require('express');
var app = express();
var bodyparser = require('body-parser');
var router_login = require('./routes/login');
var router_register = require('./routes/register');
var port = 3000;

app.set('view engine', 'pug');
app.set('views', './views');

app.use(bodyparser.urlencoded({extended:true}));
app.use('/login', router_login);
app.use('/register', router_register);
app.get('/', function(req, res){
    res.render('main');
})

app.listen(port, function(req, res){
    console.log(`Server is running on ${port}`);
})